package com.example.bmikalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    TextView rezultatTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        rezultatTextView = findViewById(R.id.rezultatTextView);
        BMIracunanje bmi = (BMIracunanje) getIntent().getSerializableExtra("BMIracunanje");
        //rezultatTextView.setText(bmi.getRez() + " ");
        rezultatTextView.setText(String.format("%.2f", bmi.getRez()));
        if (bmi.getRez() < 18.5) {
            Toast.makeText(getApplicationContext(), "Vaš BMI je nizak, što ukazuje na pothranjenost.", Toast.LENGTH_LONG).show();
        }
        if ((bmi.getRez() >= 18.5) && (bmi.getRez() < 25)) {
            Toast.makeText(getApplicationContext(), "Vaš BMI je normalnih vrednosti.", Toast.LENGTH_LONG).show();
        }
        if ((bmi.getRez() >= 25) && (bmi.getRez() < 30)) {
            Toast.makeText(getApplicationContext(), "Vaš BMI je iznad normalnih vrednosti.", Toast.LENGTH_LONG).show();
        }
        if (bmi.getRez() >= 30) {
            Toast.makeText(getApplicationContext(), "Vaš BMI je visok.", Toast.LENGTH_LONG).show();

        }
    }
}
