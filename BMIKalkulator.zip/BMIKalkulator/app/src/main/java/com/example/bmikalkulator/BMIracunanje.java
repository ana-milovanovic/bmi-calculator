package com.example.bmikalkulator;

import java.io.Serializable;

public class BMIracunanje implements Serializable {
    private Double vis;
    private Double tez;
    private Double rez;

    public Double getVis() {
        return vis;
    }

    public Double getTez() {
        return tez;
    }

    public Double getRez() {
        return rez;
    }

    public BMIracunanje(Double v, Double t, Double r){
        this.vis = v;
        this.tez = t;
        this.rez = r;
    }


}
