package com.example.bmikalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


    TextView tezinaTextView;
    TextView visinaTextView;
    EditText tezinaEditText;
    EditText visinaEditText;
    CheckBox muskoCheckBox;
    CheckBox zenskoCheckBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button izracunajBtn = (Button) findViewById(R.id.izracunajBtn);

        tezinaTextView = findViewById(R.id.tezinaTextView);
        visinaTextView = findViewById(R.id.visinaTextView);
        tezinaEditText = findViewById(R.id.tezinaEditText);
        visinaEditText = findViewById(R.id.visinaEditText);


        izracunajBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double visina = Double.parseDouble(visinaEditText.getText().toString());
                Double tezina = Double.parseDouble(tezinaEditText.getText().toString());
                Intent intent = new Intent(getApplicationContext(), Main3Activity.class);
                Double r = (Double.parseDouble(tezinaEditText.getText().toString()))/((Double.parseDouble(visinaEditText.getText().toString())/100)*(Double.parseDouble(visinaEditText.getText().toString())/100));
                BMIracunanje bmi = new BMIracunanje(visina, tezina, r);
                intent.putExtra("BMIracunanje", bmi);
                startActivity(intent);


            }
        });



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
