package com.example.bmikalkulator;

import java.io.Serializable;

public class Podaci implements Serializable {
    private Double visina;
    private Double tezina;


    public Double getVisina(){
        return visina;
    }

    public Double getTezina (){
        return tezina;
    }

    public Podaci(Double visina, Double tezina){
        this.visina = visina;
        this.tezina = tezina;
    }


}
